describe('Array', function() {
	describe('#indexOf()', function() {
		it('should return -1 when not present', function() {
			[1, 2, 3].indexOf(3).should.equal(-1);
		});
	});
});

describe('Foobar', function() {
	describe('#sayHello()', function() {
		it('should return some text', function() {
			var foobar = {
				sayHello: function() {
					return 'Hello World!';
				}
			};

		})
	})
	describe('#runMethod()', function() {
		it('should run a method', function() {
			var foobar = {
				sayHello: function() {
					return 'Hello World!';
				}
			};

		})
	})
	describe('#convertText()', function() {
		it('should convert text', function() {
			var foobar = {
				sayHello: function() {
					return 'Hello World!';
				}
			};

		})
	})
})