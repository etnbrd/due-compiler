# lanetix-microservice

Wrapper for writing JWT-authenticated microservices for internal use within Lanetix.

