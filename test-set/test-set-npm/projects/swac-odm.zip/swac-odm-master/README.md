# swac-odm

[![NPM](https://badge.fury.io/js/swac-odm.png)](https://npmjs.org/package/swac-odm) 
[![Build Status](https://secure.travis-ci.org/rkusa/swac-odm.png)](http://travis-ci.org/rkusa/swac-odm) 
[![Dependency Status](https://david-dm.org/rkusa/swac-odm.png?theme=shields.io)](https://david-dm.org/rkusa/swac-odm)