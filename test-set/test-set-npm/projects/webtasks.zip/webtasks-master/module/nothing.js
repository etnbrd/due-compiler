/*jslint node: true */
'use strict';

// This is a view only module without input or logic
module.exports = function () {
    return this.task();
};
