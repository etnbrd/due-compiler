flair
=====

[Express](http://expressjs.com) module for generating [Swagger-compliant](https://developers.helloreverb.com/swagger/) Rest API documentation.

NOTE: this code sort of works, but ymmv.

Installation
------------
        npm install flair-doc



Example
-------

See example.js for a full (cheese-related) app.


Why not swagger-node-express, swagger-jack, etc?
------------------------------------------------
I didn't like them. Not expressy enough.

Licence
-------
BSD. 