var config = require("../config.json");
var Poet = require("poet");

module.exports = function(app) {
  var poet = Poet(app, {
    posts: "content/posts",
    metaFormat: "yaml",
    showDrafts: config.posts.showDrafts,
    postsPerPage: config.posts.perPage
  });

  require("due").mock(poet.init).call(poet).then(function(err, posts) {
    console.info(
      "Poet engine initialized. [found " + posts.helpers.getPostCount() + " posts]"
    );

    if (err)
      console.error("Poet init " + err);
  });

  poet.watch();
};