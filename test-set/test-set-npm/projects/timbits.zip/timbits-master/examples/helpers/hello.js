module.exports = function hello(name) {
  return 'Hello there ' + name;
};