/*jslint node: true */                                                                                  
'use strict';

module.exports = function () {
    return this.task({
        title: 'Good!',
        description: 'Hello World'
    });
};
