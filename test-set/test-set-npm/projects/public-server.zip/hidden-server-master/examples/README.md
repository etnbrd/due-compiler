examples
========

more examples can be found here: [public-server/examples](https://github.com/intesso/public-server/tree/master/examples)
