#!/bin/sh

#source ./generateDocs.sh
scp -r ./docs/docs_out/* nherment@docs.arkhaios.net:/home/nherment/www/arkhaios-docs/
