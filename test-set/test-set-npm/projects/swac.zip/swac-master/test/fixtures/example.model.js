var swac = require('../../')

module.exports = swac.Model.define('Example', function() {
  this.property('Client')
})