jellyjs-plugin-httpserver
=========================

[![Build Status](https://travis-ci.org/alex-min/jellyjs-plugin-httpserver.png?branch=master)](https://travis-ci.org/alex-min/jellyjs-plugin-httpserver) [![Dependencies](https://david-dm.org/alex-min/jellyjs-plugin-httpserver.png)](https://david-dm.org/alex-min/jellyjs-plugin-httpserver)

httpserver plugin for jelly.js
