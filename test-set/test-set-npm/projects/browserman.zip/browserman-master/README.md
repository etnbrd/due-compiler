[![Build Status](https://api.travis-ci.org/cortexjs/browserman.svg?branch=master)](https://travis-ci.org/cortexjs/browserman)

Browserman makes it easy to test your javascript code in real browsers.

### Preparation:

run the server:

	npm run start
	
then open browsers and visit '/public/browser.html' on the server