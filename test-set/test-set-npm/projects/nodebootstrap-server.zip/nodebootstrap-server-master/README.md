nodebootstrap-server
====================

Server component for [NodeBootstrap](https://github.com/inadarei/nodebootstrap)
