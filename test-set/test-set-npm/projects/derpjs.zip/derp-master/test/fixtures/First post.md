This is the "meta" section of your blog post. Add `key:value` lines here and they will be converted to meta data inside the post object. Everything else will be ignored

title: oops!
date: 5 May 2014
url: first-post
tags: web, something, tag-test, another tag

My First Post
==============

This is the first post on my fake blog