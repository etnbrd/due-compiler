module.exports = {
	privilige_level: { type: Number, default: 1, min:0, max: 50, permissions: {w: 49, r: 0}}
};