require("iced-coffee-script");

module.exports = require("./lib/mapper");
