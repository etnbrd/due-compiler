test
========

tests can be found here: [public-server/test](https://github.com/intesso/public-server/tree/master/test)
