var sik = require('../../');

var app = module.exports = sik({root: __dirname});
