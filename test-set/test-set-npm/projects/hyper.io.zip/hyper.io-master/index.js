module.exports = require('./lib/hyper.js');
