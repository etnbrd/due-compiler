/** @jsx React.DOM */
var React = require('react'),
    notfound = require('NotFoundModule'),

Bug = React.createClass({
    render: function () {
        return (
            <div>OK!</div>
        );
    }
});

module.exports = Bug;
