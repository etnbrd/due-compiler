(function base1() {
	console.log(arguments.callee.name);
})();
