claus
=====

Creates express app's routes for commands and queries, Loading them from the file system.