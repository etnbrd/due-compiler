module.exports = {
    logOpts: {
        level: "error",
        colorize: true,
        timestamp: true
    }
};