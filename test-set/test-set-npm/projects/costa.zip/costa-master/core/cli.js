require('coffee-script');
module.exports = require('./cli.coffee');
