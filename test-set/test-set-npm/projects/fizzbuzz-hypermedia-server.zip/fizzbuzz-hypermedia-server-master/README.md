fizzbuzz-hypermedia-server
==========================

Solving FizzBuzz with hypermedia

[FizzBuzz-as-a-Service](http://fizzbuzzaas.herokuapp.com/)
