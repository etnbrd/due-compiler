var Example = require('./example.model')

Example.extend(function() {
  this.property('Server')
})