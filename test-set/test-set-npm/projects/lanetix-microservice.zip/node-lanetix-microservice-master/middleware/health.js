'use strict';

module.exports = function (req, res) {
  res.status(204).send();
};
