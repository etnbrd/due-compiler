sonea
=====

[![Build Status](https://travis-ci.org/Naxmeify/sonea.svg?branch=master)](https://travis-ci.org/Naxmeify/sonea)

[![Code Climate](https://codeclimate.com/github/Naxmeify/sonea.png)](https://codeclimate.com/github/Naxmeify/sonea)
[![Test Coverage](https://codeclimate.com/github/Naxmeify/sonea/badges/coverage.svg)](https://codeclimate.com/github/Naxmeify/sonea)

[![NPM version](https://badge.fury.io/js/sonea.svg)](http://badge.fury.io/js/sonea)
[![GitHub version](https://badge.fury.io/gh/Naxmeify%2Fsonea.png)](http://badge.fury.io/gh/Naxmeify%2Fsonea)
[![Dependency Status](https://gemnasium.com/Naxmeify/sonea.svg)](https://gemnasium.com/Naxmeify/sonea)


[![NPM](https://nodei.co/npm/sonea.png?downloads=true&stars=true)](https://nodei.co/npm/sonea/)