# loopback-sdk-angular-cli

**NOTE: The loopback-sdk-angular-cli module supersedes [loopback-angular-cli](https://www.npmjs.org/loopback-angular-cli). Please update your package.json accordingly.**

CLI tools for the [LoopBack AngularJS SDK](https://github.com/strongloop/loopback-sdk-angular).

See the official [LoopBack AngularJS SDK documentation](http://docs.strongloop.com/display/LB/AngularJS+JavaScript+SDK)
for more information.

## Mailing List

Discuss features and ask questions on [LoopBack Forum](https://groups.google.com/forum/#!forum/loopbackjs).

