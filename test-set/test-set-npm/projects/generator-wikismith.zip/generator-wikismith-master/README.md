Wikismith
---------------
Wikismith is a fun static site generator for fans of gulp and bower

## Get Started

* npm install generator-wikismith

* mkdir my-awesome-site

* cd my-awesome-site

* yo wikismith

* gulp

* Open http://localhost:9292

## Learn more

* http://wikismith.com

## Updates

* 8/4/2014 - Added bespoke.js presentations to wikismith_themes

* 8/3/2014 - Added blog functionality via page_snippets.

* 8/1/2014 - Release

