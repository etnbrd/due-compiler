# InChI server

This module runs a server that converts InChI strings to molecules.

##
