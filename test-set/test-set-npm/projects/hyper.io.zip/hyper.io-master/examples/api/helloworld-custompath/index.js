'use strict';
require('./custom_path/app.js');
