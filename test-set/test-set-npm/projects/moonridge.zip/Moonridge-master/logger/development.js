module.exports = {
    logOpts: {
        level: "debug",
        colorize: true,
        timestamp: true
    }
};