var express = require("express");

var app = express();

app.configure(function(){
    app.use(express.bodyParser());
    app.use(function(req, res, next){
        console.log('\n'+ req.method +' '+req.url,'\n', req.body);
        next();
    });
});

app.get('/', function(req, res){
  res.send('hello world');
});

require("./claus")(app, "./sample");

console.log ("listening on port 3000");
app.listen(3000);